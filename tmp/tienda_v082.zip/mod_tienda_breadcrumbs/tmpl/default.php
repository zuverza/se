<?php defined('_JEXEC') or die('Restricted access'); ?>

<div id="tienda_breadcrumb">
<?php echo $pathway; ?>
</div>