-- -----------------------------------------------------
-- Table `#__tienda_manufacturers` sample data
-- -----------------------------------------------------

INSERT INTO `#__tienda_manufacturers` (`manufacturer_id`, `manufacturer_name`, `manufacturer_image`, `manufacturer_enabled`, `created_date`, `modified_date`) VALUES
(1, 'HTC', '', 1, NOW(), NOW()),
(2, 'Acer', '', 1, NOW(), NOW()),
(3, 'AMD', '', 1, NOW(), NOW()),
(4, 'Apple', '', 1, NOW(), NOW()),
(5, 'AT&T', '', 1, NOW(), NOW()),
(6, 'Canon', '', 1, NOW(), NOW()),
(7, 'Dell', '', 1, NOW(), NOW()),
(8, 'Gateway', '', 1, NOW(), NOW());