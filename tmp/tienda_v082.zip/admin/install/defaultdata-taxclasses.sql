-- -----------------------------------------------------
-- Dumping data for table `#__tienda_taxclasses`
-- -----------------------------------------------------

INSERT IGNORE INTO `#__tienda_taxclasses` (`tax_class_id`, `tax_class_name`, `tax_class_description`, `created_date`, `modified_date`) VALUES
(1, 'Taxable Goods', '', NOW(), NOW()),
(2, 'Non-Taxable Goods', '', NOW(), NOW());