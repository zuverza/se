-- -----------------------------------------------------
-- Dumping data for table `#__tienda_geozonetypes`
-- -----------------------------------------------------
INSERT IGNORE INTO `#__tienda_geozonetypes` (`geozonetype_id`, `geozonetype_name`, `created_date`, `modified_date`) VALUES
(1, 'Tax Zones', NOW(), NOW()),
(2, 'Shipping Zones', NOW(), NOW());