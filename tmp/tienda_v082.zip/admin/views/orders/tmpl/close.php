<?php defined('_JEXEC') or die('Restricted access'); ?>

    <script type="text/javascript">
    window.parent.tiendaAddProductsToOrder();
    </script>
